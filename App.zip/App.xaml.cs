﻿using System.Windows;

namespace CNC_Improvements_gcode_solids
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }
}
